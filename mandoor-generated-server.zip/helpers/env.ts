require('dotenv').config()

export default {
}