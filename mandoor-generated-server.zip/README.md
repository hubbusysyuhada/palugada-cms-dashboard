# Awesome Project build with Mandoor Server Generator

Steps to run this project:

1. Run `npm i` command
2. Make sure your .env file value is correct
3. Run `npm start` command
